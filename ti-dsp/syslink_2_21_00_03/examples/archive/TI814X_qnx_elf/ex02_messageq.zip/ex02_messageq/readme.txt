MessageQ Example

Program Logic:
The slave creates a messsage to pass data around. The GPP sends a message to 
the slave core with a dummy payload. The slave then sends the message back to
the GPP. This process is repeated 15 times.


