#
#  ======== readme.txt ========
#

ex63_vpssammu - VPSS master core, AMMU configuration, virtual memory map


This example illustrates how to build a VPSS executable configured as
the master core of the Ducati subsystem. The AMMU is configured to
map the executable's virtual addresses to physical memory such that
the program's code and data has a cache-able view and the physical map
has a non-cached view.

Look in shared/config.bld to see the memory map.


To build and run the example
====================================
Prompt: [host] - run these commands on your build host (Linux, Windows)
Prompt: [target] - run these commands on your embedded system

1. Edit products.mak and specify the product install paths.

    [host] cd ex63_vpssammu
    [host] edit products.mak

2. Run make to build the example.

    [host] cd ex63_vpssammu
    [host] make

3. Build the install goal to copy files to your target file system.

    [host] cd ex63_vpssammu
    [host] make install EXEC_DIR=/target_file_system/...

4. Use the run.sh script to run the example.

    [target] cd ex63_vpssammu/debug
    [target] run.sh

    You should see the following output.

    # ./run.sh
    + ./slaveloader startup VPSS-M3 server_vpss.xem3 memmap.txt
    Attached to slave procId 2.
    Mapping SV: 0x1e100000, SP: 0x8e100000, MP: 0x8e100000,
      size 0x200000, mask 0x4, cached 1
    ProcMgr_map succeeded
    Mapped entries in memmap.txt to slave procId 2.
    Loading procId 2.
    Loaded file server_vpss.xem3 on slave procId 2.
    Started slave procId 2.
    + ./app_host VPSS-M3
    --> Main_main:
    --> App_setup:
    <-- App_setup: status=0
    --> App_run:
    App_run:    sending message 1
    App_run:   received message 1
    App_run:    sending message 2
    App_run:   received message 2
    App_run:    sending message 3
    App_run:   received message 3
    App_run:    sending message 4
    App_run:   received message 4
    App_run:    sending message 5
    App_run:   received message 5
    <-- App_run: 0
    --> App_destroy:
    <-- App_destroy: status=0
    <-- Main_main:
    + ./slaveloader shutdown VPSS-M3
    Stopped slave procId 2.
    Unloaded slave procId 2.
    Detached from slave procId 2.


Discussion Points
===================

 1. The application memory map is defined in shared/config.bld. The comment
    gives a nice picture, but the actual addresses are specified in the
    platform instance.

    Build.platformTable["ti.platforms.evmTI814X:vpss"] = { ... };

    Look at the externalMemoryMap property. To move the shared regions,
    edit the SR_0 and SR_1 objects. To move the program address, edit
    the VPSS_PROG object.


 2. The AMMU configuration is done in vpss/Vpss.cfg, however, the base
    addresses are defined in shared/config.bld. Look for the ammu object.
    Keep in mind that the AMMU configuration must be aligned on the page
    size. This example is using a 32 MB page, so the base addresses are
    aligned on this boundary.


 3. The memmap.txt file defines the memory map for the loader. It must
    be the same as the memory map in config.bld. Be sure to update both.


 4. Because the AMMU configuration is done by the vpss executable (instead
    of SysLink) there is a boot strap problem. You cannot jump to the
    entry point (virtual address) until the AMMU has been configured.
    This is accomplished by hijacking the program's entry point and
    configuring the AMMU before jumping to the real entry point. This
    bootstrap code must be placed in L2_BOOT memory which is automatically
    configured in the AMMU. Look at reset.s to see the assembly file which
    does this. Look at linker.cmd to see the code placement directives.

    You will need to apply the same changes to your executable.
