Metal Example

Program Logic:
Illustrate how to build a non-bios dsp executable which can be loaded
by SysLink slaveloader.
