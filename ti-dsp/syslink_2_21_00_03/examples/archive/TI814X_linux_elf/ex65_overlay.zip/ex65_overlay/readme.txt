#
#  ======== readme.txt ========
#

ex65_overlay - Slave executable has overlay sections

This examples illustrates how to build and run a slave executable which
contains overlay sections. That is, there are two code sections with the
same run address but different load addresses. The sections are loaded
to their load address by the loader, but the executable itself must copy
the section into the run address before executing the functions in these
sections. This is typically used for running different code sections from
internal memory.


To build and run the example
====================================
Prompt: [host] - run these commands on your build host (Linux, Windows)
Prompt: [target] - run these commands on your embedded system

 1. Edit products.mak and specify the product install paths.

    [host] cd ex65_overlay
    [host] edit products.mak

 2. Use make to build the example.

    [host] cd ex65_overlay
    [host] make

 3. Use the install goal to copy files to your target file system.

    [host] cd ex65_overlay
    [host] make install EXEC_DIR=/target_file_system/...

 4. Use the run.sh script to run the example.

    [target] cd ex65_overlay/debug
    [target] run.sh

    You should see the following output.

    [target] cd ex65_overlay/release
    [target] ./run.sh
    + ./slaveloader startup DSP server_dsp.xe674
    Attached to slave procId 0.
    Loading procId 0.
    Loaded file server_dsp.xe674 on slave procId 0.
    Started slave procId 0.
    + ./app_host DSP
    --> Main_main:
    --> App_setup:
    <-- App_setup: status=0
    --> App_run:
    App_run: loop=1
    App_run: sending message for Server_Fxn_01
    App_run: x=21 (expected 21)
    App_run: sending message for Server_Fxn_02
    App_run: x=61 (expected 61)
    App_run: loop=2
    App_run: sending message for Server_Fxn_01
    App_run: x=21 (expected 21)
    App_run: sending message for Server_Fxn_02
    App_run: x=61 (expected 61)
    App_run: loop=3
    App_run: sending message for Server_Fxn_01
    App_run: x=21 (expected 21)
    App_run: sending message for Server_Fxn_02
    App_run: x=61 (expected 61)
    App_run: loop=4
    App_run: sending message for Server_Fxn_01
    App_run: x=21 (expected 21)
    App_run: sending message for Server_Fxn_02
    App_run: x=61 (expected 61)
    App_run: loop=5
    App_run: sending message for Server_Fxn_01
    App_run: x=21 (expected 21)
    App_run: sending message for Server_Fxn_02
    App_run: x=61 (expected 61)
    <-- App_run: 0
    --> App_destroy:
    <-- App_destroy: status=0
    <-- Main_main:
    + ./slaveloader shutdown DSP
    Stopped slave procId 0.
    Unloaded slave procId 0.
    Detached from slave procId 0.


Discussion Points
===================

 1. The file overlay.cmd instructs the linker to load the given sections
    to DSP_PROG memory but to link the code to run from IRAM memory. Both
    of these memory sections are defined in the config.bld file.

 2. The file overlay.cmd also defines symbols which can be used at runtime
    to know where the linker placed the given sections and how big they are.
    Look for these symbols in Server.c to see how they are used.

    Server_Fxn_01_load_addr
    Server_Fxn_01_load_size
    Server_Fxn_01_run_addr

 3. The functions are placed in named sections using the CODE_SECTION
    pragma. Look in Server.c for an example.
